import React from 'react'

class StreamCreate extends React.Component {
    render() {
        return <div>StreamCreate</div>
    }
}

export default StreamCreate;