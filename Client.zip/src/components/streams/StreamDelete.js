import React from 'react'

class StreamDelete extends React.Component {
    render() {
        return <div>StreamDelete</div>
    }
}

export default StreamDelete;