import React from 'react'

class StreamEdit extends React.Component {
    render() {
        return <div>StreamEdit</div>
    }
}

export default StreamEdit;