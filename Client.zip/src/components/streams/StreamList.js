import React from 'react'

class StreamList extends React.Component {
    render() {
        return <div>StreamList</div>
    }
}

export default StreamList;