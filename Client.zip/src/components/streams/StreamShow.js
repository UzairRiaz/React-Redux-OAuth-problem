import React from 'react'

class StreamShow extends React.Component {
    render() {
        return <div>StreamShow</div>
    }
}

export default StreamShow;